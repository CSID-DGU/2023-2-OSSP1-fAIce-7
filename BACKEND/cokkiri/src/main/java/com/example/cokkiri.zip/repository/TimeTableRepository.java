package com.example.cokkiri.repository;

import com.example.cokkiri.model.TimeTable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TimeTableRepository extends JpaRepository<TimeTable,String> {
}
