package com.example.cokkiri.utils;

import java.util.Arrays;
import java.util.List;

public class HobbyUtils {
    public static final List<String> HOBBIES = Arrays.asList(
            "축구", "농구", "야구", "당구",
            "컴퓨터", "스위치", "보드게임", "오락실",
            "영화", "드라마", "뮤지컬", "전시회",
            "의류", "악세사리", "화장품", "네일",
            "강아지", "고양이", "조류", "식물",
            "그림", "음악", "사진", "글쓰기"
    );
}
